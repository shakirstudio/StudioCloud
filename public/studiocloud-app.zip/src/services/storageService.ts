import { 
  ref, 
  uploadBytesResumable, 
  getDownloadURL, 
  deleteObject,
  UploadTask
} from 'firebase/storage';
import { 
  collection, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  deleteDoc, 
  query, 
  orderBy, 
  increment 
} from 'firebase/firestore';
import { storage, db, auth, handleFirestoreError, OperationType } from '../firebase/config';
import { MediaItem, MediaType, UploadProgressItem } from '../types';
import { 
  getStudioById, 
  updateStudio, 
  getGalleries, 
  updateGallery, 
  addActivityLog, 
  verifyStorageQuotaBackend 
} from './studioService';

// File Validation Constants
export const MAX_IMAGE_SIZE_BYTES = 100 * 1024 * 1024; // 100 MB
export const MAX_VIDEO_SIZE_BYTES = 250 * 1024 * 1024; // 250 MB

export const ALLOWED_IMAGE_TYPES = [
  'image/jpeg',
  'image/jpg',
  'image/png',
  'image/webp',
  'image/avif',
  'image/tiff',
  'image/x-adobe-dng',
  'image/heic'
];

export const ALLOWED_VIDEO_TYPES = [
  'video/mp4',
  'video/quicktime',
  'video/webm'
];

export interface ValidationResult {
  valid: boolean;
  error?: string;
  fileType?: MediaType;
}

export function validateMediaFile(file: File): ValidationResult {
  const isImage = ALLOWED_IMAGE_TYPES.includes(file.type) || file.type.startsWith('image/');
  const isVideo = ALLOWED_VIDEO_TYPES.includes(file.type) || file.type.startsWith('video/');

  if (!isImage && !isVideo) {
    return {
      valid: false,
      error: `Unsupported file type "${file.type || file.name.split('.').pop()}". Only photography (JPEG, PNG, WEBP, TIFF, RAW) and video (MP4, MOV, WEBM) files are permitted.`
    };
  }

  const fileType: MediaType = isVideo ? 'video' : 'image';
  const maxSize = isVideo ? MAX_VIDEO_SIZE_BYTES : MAX_IMAGE_SIZE_BYTES;

  if (file.size > maxSize) {
    return {
      valid: false,
      error: `File "${file.name}" exceeds maximum allowed size of ${isVideo ? '250 MB' : '100 MB'}.`
    };
  }

  if (file.size <= 0) {
    return {
      valid: false,
      error: `File "${file.name}" is empty (0 bytes).`
    };
  }

  return { valid: true, fileType };
}

// Active upload tasks tracker for cancellation
const activeUploadTasks = new Map<string, UploadTask>();

export function cancelUploadTask(uploadId: string): boolean {
  const task = activeUploadTasks.get(uploadId);
  if (task) {
    task.cancel();
    activeUploadTasks.delete(uploadId);
    return true;
  }
  return false;
}

export async function uploadMediaFile(params: {
  uploadId: string;
  studioId: string;
  galleryId: string;
  file: File;
  userId: string;
  onProgress?: (progressPercent: number, bytesTransferred: number) => void;
}): Promise<MediaItem> {
  const { uploadId, studioId, galleryId, file, userId, onProgress } = params;

  // 1. Client-side file type & volumetric validation
  const validation = validateMediaFile(file);
  if (!validation.valid || !validation.fileType) {
    throw new Error(validation.error || 'Invalid media file.');
  }

  // 2. Pre-flight storage quota check against 10 GB limit
  const currentStudio = await getStudioById(studioId);
  if (!currentStudio) {
    throw new Error('Target photography studio not found.');
  }

  const currentUsed = currentStudio.storageUsedBytes || 0;
  const quota = currentStudio.storageAllocationBytes || 10000000000;
  const quotaResult = await verifyStorageQuotaBackend(currentUsed, quota, file.size);

  if (!quotaResult.allowed) {
    throw new Error(
      `Upload rejected: Studio storage quota exceeded. Required: ${(file.size / (1000 * 1000)).toFixed(1)} MB, Remaining: ${(quotaResult.remainingBytes / (1000 * 1000)).toFixed(1)} MB.`
    );
  }

  // 3. Prepare storage reference
  const mediaId = `media_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const sanitizedName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
  const storagePath = `studios/${studioId}/galleries/${galleryId}/${mediaId}_${sanitizedName}`;
  const storageRef = ref(storage, storagePath);

  // 4. Execute upload task
  const uploadTask = uploadBytesResumable(storageRef, file, {
    contentType: file.type,
    customMetadata: {
      studioId,
      galleryId,
      uploadedBy: userId,
      originalName: file.name,
    }
  });

  activeUploadTasks.set(uploadId, uploadTask);

  return new Promise((resolve, reject) => {
    uploadTask.on(
      'state_changed',
      (snapshot) => {
        const percent = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
        if (onProgress) {
          onProgress(Math.min(99.9, percent), snapshot.bytesTransferred);
        }
      },
      (error) => {
        activeUploadTasks.delete(uploadId);
        let errorMsg = error.message;
        if (error.code === 'storage/unauthorized') {
          errorMsg = 'Upload blocked by Firebase Storage Security Rules: Unauthorized tenant access or invalid file format.';
        } else if (error.code === 'storage/canceled') {
          errorMsg = 'Upload cancelled by user.';
        } else if (error.code === 'storage/bucket-not-found') {
          errorMsg = 'Firebase Storage bucket not found or not activated. Please verify Firebase Storage in your Firebase Console.';
        }
        reject(new Error(errorMsg));
      },
      async () => {
        activeUploadTasks.delete(uploadId);
        try {
          const downloadUrl = await getDownloadURL(uploadTask.snapshot.ref);
          const now = new Date().toISOString();

          const mediaItem: MediaItem = {
            id: mediaId,
            studioId,
            galleryId,
            fileName: file.name,
            fileType: validation.fileType!,
            mimeType: file.type,
            sizeBytes: file.size,
            storagePath,
            downloadUrl,
            uploadedBy: userId,
            uploadedAt: now,
          };

          // 5. Save metadata in subcollection: studios/{studioId}/galleries/{galleryId}/media/{mediaId}
          const mediaDocPath = `studios/${studioId}/galleries/${galleryId}/media/${mediaId}`;
          await setDoc(doc(db, 'studios', studioId, 'galleries', galleryId, 'media', mediaId), mediaItem);

          // 6. Atomically update Studio storageUsedBytes
          await updateStudio(studioId, {
            storageUsedBytes: (currentStudio.storageUsedBytes || 0) + file.size,
          });

          // 7. Update gallery metadata (photoCount/videoCount and storageBytes)
          const galleryDocRef = doc(db, 'studios', studioId, 'galleries', galleryId);
          const gallerySnap = await getDoc(galleryDocRef);
          if (gallerySnap.exists()) {
            const gData = gallerySnap.data();
            const isVid = validation.fileType === 'video';
            await updateGallery(studioId, galleryId, {
              storageBytes: (gData.storageBytes || 0) + file.size,
              photoCount: isVid ? (gData.photoCount || 0) : (gData.photoCount || 0) + 1,
              videoCount: isVid ? ((gData.videoCount || 0) + 1) : (gData.videoCount || 0),
              coverImageUrl: gData.coverImageUrl || (!isVid ? downloadUrl : undefined),
            });
          }

          // 8. Log audit trail
          await addActivityLog({
            studioId,
            userId,
            userEmail: auth.currentUser?.email || 'photographer',
            action: `Uploaded ${validation.fileType === 'video' ? 'Video' : 'Photo'}`,
            targetType: 'Media Asset',
            targetName: file.name,
          });

          if (onProgress) onProgress(100, file.size);
          resolve(mediaItem);
        } catch (err: any) {
          reject(err);
        }
      }
    );
  });
}

// Fetch all media items for a gallery
export async function getGalleryMedia(studioId: string, galleryId: string): Promise<MediaItem[]> {
  const path = `studios/${studioId}/galleries/${galleryId}/media`;
  try {
    const q = query(
      collection(db, 'studios', studioId, 'galleries', galleryId, 'media'),
      orderBy('uploadedAt', 'desc')
    );
    const snap = await getDocs(q);
    const items: MediaItem[] = [];
    snap.forEach((d) => {
      items.push({ id: d.id, ...d.data() } as MediaItem);
    });
    return items;
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

// Delete media item from storage and database
export async function deleteMediaItem(params: {
  studioId: string;
  galleryId: string;
  mediaId: string;
  storagePath: string;
  sizeBytes: number;
  fileName: string;
  fileType: MediaType;
}): Promise<void> {
  const { studioId, galleryId, mediaId, storagePath, sizeBytes, fileName, fileType } = params;

  // 1. Delete binary from Firebase Storage
  try {
    const storageRef = ref(storage, storagePath);
    await deleteObject(storageRef);
  } catch (storageErr: any) {
    console.warn('Storage object delete warning (might already be deleted):', storageErr.message);
  }

  // 2. Delete Firestore document
  const docPath = `studios/${studioId}/galleries/${galleryId}/media/${mediaId}`;
  try {
    await deleteDoc(doc(db, 'studios', studioId, 'galleries', galleryId, 'media', mediaId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, docPath);
  }

  // 3. Atomically decrement Studio storageUsedBytes
  const currentStudio = await getStudioById(studioId);
  if (currentStudio) {
    const newUsed = Math.max(0, (currentStudio.storageUsedBytes || 0) - sizeBytes);
    await updateStudio(studioId, { storageUsedBytes: newUsed });
  }

  // 4. Decrement Gallery photoCount and storageBytes
  const galleryDocRef = doc(db, 'studios', studioId, 'galleries', galleryId);
  const gallerySnap = await getDoc(galleryDocRef);
  if (gallerySnap.exists()) {
    const gData = gallerySnap.data();
    const isVid = fileType === 'video';
    await updateGallery(studioId, galleryId, {
      storageBytes: Math.max(0, (gData.storageBytes || 0) - sizeBytes),
      photoCount: !isVid ? Math.max(0, (gData.photoCount || 1) - 1) : (gData.photoCount || 0),
      videoCount: isVid ? Math.max(0, (gData.videoCount || 1) - 1) : (gData.videoCount || 0),
    });
  }

  // 5. Audit log
  await addActivityLog({
    studioId,
    userId: auth.currentUser?.uid || 'system',
    userEmail: auth.currentUser?.email || 'photographer',
    action: 'Deleted Media Asset',
    targetType: 'Media Asset',
    targetName: fileName,
  });
}
