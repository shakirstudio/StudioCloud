import fs from 'fs';
import path from 'path';

export interface GalleryDoc {
  id: string;
  studioId: string;
  title: string;
  slug?: string;
  status: 'draft' | 'published' | 'archived';
  privacy: 'public' | 'unlisted' | 'password_protected' | 'private';
  accessPassword?: string;
  shareToken?: string;
  expiresAt?: string | null;
  coverPhotoUrl?: string;
  mediaCount?: number;
  [key: string]: any;
}

export interface MediaDoc {
  id: string;
  studioId: string;
  galleryId: string;
  originalName: string;
  storageUrl: string;
  sizeBytes: number;
  mimeType: string;
  width?: number;
  height?: number;
  [key: string]: any;
}

export interface ProofDoc {
  id: string;
  studioId: string;
  galleryId: string;
  mediaId: string;
  clientUid?: string;
  clientEmail?: string;
  clientName?: string;
  isFavorite?: boolean;
  isInAlbum?: boolean;
  comments?: any[];
  notes?: string;
  createdAt?: string;
  updatedAt?: string;
  claimedAt?: string;
  claimedByEmail?: string;
  [key: string]: any;
}

// In-memory test repository for mock/simulation modes
const inMemoryGalleries = new Map<string, GalleryDoc>();
const inMemoryMedia = new Map<string, MediaDoc[]>();
const inMemoryProofing = new Map<string, Map<string, ProofDoc>>();

/**
 * Configure mock data for tests.
 */
export function setMockGalleryForTesting(studioId: string, gallery: GalleryDoc) {
  const key = `${studioId}:${gallery.id}`;
  inMemoryGalleries.set(key, gallery);
}

export function setMockMediaForTesting(studioId: string, galleryId: string, media: MediaDoc[]) {
  const key = `${studioId}:${galleryId}`;
  inMemoryMedia.set(key, media);
}

export function setMockProofingForTesting(studioId: string, galleryId: string, proof: ProofDoc) {
  const key = `${studioId}:${galleryId}`;
  if (!inMemoryProofing.has(key)) {
    inMemoryProofing.set(key, new Map());
  }
  inMemoryProofing.get(key)!.set(proof.id, proof);
}

export function resetMockDataForTesting() {
  inMemoryGalleries.clear();
  inMemoryMedia.clear();
  inMemoryProofing.clear();
}

/**
 * Resolves Firebase project config.
 */
function getFirebaseConfig(): { projectId: string; firestoreDatabaseId: string; apiKey: string } {
  try {
    const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
    if (fs.existsSync(configPath)) {
      const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      return {
        projectId: config.projectId || 'totemic-metric-wmzf6',
        firestoreDatabaseId: config.firestoreDatabaseId || 'ai-studio-studiocloud-96ce23e4-825f-4ad2-98b0-7123de2321ac',
        apiKey: config.apiKey || '',
      };
    }
  } catch {
    // ignore
  }
  return {
    projectId: 'totemic-metric-wmzf6',
    firestoreDatabaseId: 'ai-studio-studiocloud-96ce23e4-825f-4ad2-98b0-7123de2321ac',
    apiKey: '',
  };
}

/**
 * Decodes Firestore REST format into a plain JavaScript object.
 */
function decodeFirestoreValue(v: any): any {
  if (!v || typeof v !== 'object') return v;
  if ('stringValue' in v) return v.stringValue;
  if ('integerValue' in v) return Number(v.integerValue);
  if ('doubleValue' in v) return Number(v.doubleValue);
  if ('booleanValue' in v) return v.booleanValue;
  if ('nullValue' in v) return null;
  if ('timestampValue' in v) return v.timestampValue;
  if ('arrayValue' in v) return (v.arrayValue.values || []).map(decodeFirestoreValue);
  if ('mapValue' in v) {
    const res: Record<string, any> = {};
    for (const [k, val] of Object.entries(v.mapValue.fields || {})) {
      res[k] = decodeFirestoreValue(val);
    }
    return res;
  }
  return v;
}

function decodeFirestoreDoc(doc: any): any {
  if (!doc || !doc.fields) return null;
  const id = doc.name ? doc.name.split('/').pop() : '';
  const data: Record<string, any> = { id };
  for (const [k, v] of Object.entries(doc.fields)) {
    data[k] = decodeFirestoreValue(v);
  }
  return data;
}

/**
 * Encodes a plain JavaScript object into Firestore REST format.
 */
function encodeFirestoreValue(val: any): any {
  if (val === null || val === undefined) return { nullValue: null };
  if (typeof val === 'string') return { stringValue: val };
  if (typeof val === 'boolean') return { booleanValue: val };
  if (typeof val === 'number') {
    return Number.isInteger(val) ? { integerValue: String(val) } : { doubleValue: val };
  }
  if (Array.isArray(val)) {
    return { arrayValue: { values: val.map(encodeFirestoreValue) } };
  }
  if (typeof val === 'object') {
    const fields: Record<string, any> = {};
    for (const [k, v] of Object.entries(val)) {
      if (v !== undefined) {
        fields[k] = encodeFirestoreValue(v);
      }
    }
    return { mapValue: { fields } };
  }
  return { stringValue: String(val) };
}

function encodeFirestoreDoc(obj: Record<string, any>): Record<string, any> {
  const fields: Record<string, any> = {};
  for (const [k, v] of Object.entries(obj)) {
    if (k !== 'id' && v !== undefined) {
      fields[k] = encodeFirestoreValue(v);
    }
  }
  return { fields };
}

/**
 * Fetches gallery document from test mock or Firestore REST.
 */
export async function fetchGalleryDocument(
  studioId: string,
  galleryId: string,
  idToken?: string
): Promise<GalleryDoc | null> {
  const mockKey = `${studioId}:${galleryId}`;
  if (inMemoryGalleries.has(mockKey)) {
    return inMemoryGalleries.get(mockKey)!;
  }

  const { projectId, firestoreDatabaseId, apiKey } = getFirebaseConfig();
  const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/${firestoreDatabaseId}/documents/studios/${studioId}/galleries/${galleryId}${
    idToken ? '' : `?key=${apiKey}`
  }`;

  const headers: Record<string, string> = {};
  if (idToken) {
    headers['Authorization'] = `Bearer ${idToken}`;
  }

  try {
    const response = await fetch(url, { headers });
    if (response.status === 404) {
      return null;
    }
    if (!response.ok) {
      return null;
    }
    const raw = await response.json();
    return decodeFirestoreDoc(raw) as GalleryDoc;
  } catch {
    return null;
  }
}

/**
 * Fetches gallery media items.
 */
export async function fetchGalleryMedia(
  studioId: string,
  galleryId: string,
  idToken?: string
): Promise<MediaDoc[]> {
  const mockKey = `${studioId}:${galleryId}`;
  if (inMemoryMedia.has(mockKey)) {
    return inMemoryMedia.get(mockKey)!;
  }

  const { projectId, firestoreDatabaseId, apiKey } = getFirebaseConfig();
  const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/${firestoreDatabaseId}/documents/studios/${studioId}/galleries/${galleryId}/media${
    idToken ? '' : `?key=${apiKey}`
  }`;

  const headers: Record<string, string> = {};
  if (idToken) {
    headers['Authorization'] = `Bearer ${idToken}`;
  }

  try {
    const response = await fetch(url, { headers });
    if (!response.ok) return [];
    const data = await response.json();
    if (!data.documents) return [];
    return data.documents.map(decodeFirestoreDoc) as MediaDoc[];
  } catch {
    return [];
  }
}

/**
 * Fetches gallery proofing items.
 */
export async function fetchGalleryProofing(
  studioId: string,
  galleryId: string,
  idToken?: string
): Promise<ProofDoc[]> {
  const mockKey = `${studioId}:${galleryId}`;
  if (inMemoryProofing.has(mockKey)) {
    return Array.from(inMemoryProofing.get(mockKey)!.values());
  }

  const { projectId, firestoreDatabaseId, apiKey } = getFirebaseConfig();
  const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/${firestoreDatabaseId}/documents/studios/${studioId}/galleries/${galleryId}/proofing${
    idToken ? '' : `?key=${apiKey}`
  }`;

  const headers: Record<string, string> = {};
  if (idToken) {
    headers['Authorization'] = `Bearer ${idToken}`;
  }

  try {
    const response = await fetch(url, { headers });
    if (!response.ok) return [];
    const data = await response.json();
    if (!data.documents) return [];
    return data.documents.map(decodeFirestoreDoc) as ProofDoc[];
  } catch {
    return [];
  }
}

/**
 * Saves a proofing document to Firestore.
 */
export async function saveProofingDocument(
  studioId: string,
  galleryId: string,
  proofId: string,
  data: Record<string, any>,
  idToken?: string
): Promise<void> {
  const mockKey = `${studioId}:${galleryId}`;
  if (!inMemoryProofing.has(mockKey)) {
    inMemoryProofing.set(mockKey, new Map());
  }
  const currentMap = inMemoryProofing.get(mockKey)!;
  currentMap.set(proofId, { id: proofId, ...data } as ProofDoc);

  const { projectId, firestoreDatabaseId, apiKey } = getFirebaseConfig();
  const url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/${firestoreDatabaseId}/documents/studios/${studioId}/galleries/${galleryId}/proofing/${proofId}${
    idToken ? '' : `?key=${apiKey}`
  }`;

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (idToken) {
    headers['Authorization'] = `Bearer ${idToken}`;
  }

  try {
    await fetch(url, {
      method: 'PATCH',
      headers,
      body: JSON.stringify(encodeFirestoreDoc(data)),
    });
  } catch {
    // Fall back to memory
  }
}
